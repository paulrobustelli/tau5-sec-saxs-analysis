# Early bAIes/OpenMM analysis

This snapshot covers the first 1.35 ns of the concurrent WT and W397A/W433A
validation trajectories. The first 0.20 ns temperature ramp was excluded from
reported ensemble means.

The plot contains mass-weighted whole-construct radius of gyration, DSSP
alpha-helix fraction versus time, and residue-specific DSSP alpha-helical
propensity. These short trajectories retain starting-structure memory and are
not converged production ensembles.

See `early_summary.csv` for summary statistics, `early_timeseries.csv` for
framewise values, and `early_per_residue_helicity.csv` for residue profiles.
