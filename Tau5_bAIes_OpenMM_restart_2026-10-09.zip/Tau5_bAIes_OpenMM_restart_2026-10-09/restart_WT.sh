#!/usr/bin/env bash
set -euo pipefail
python_bin=${1:-python}
root=$(cd "$(dirname "$0")" && pwd)
code="$root/code"
run="$root/Restart_Snapshot_2026-10-09/WT"

"$python_bin" "$code/bAIes_openMM.py" \
  -pdb "$run/protein.pdb" -ff "$code/coil_202602.xml" \
  -cmap "$code/cmap_20240524.cmap" -baies "$run/baies_params.dat" \
  -restart_state "$run/restart_state.xml" \
  -xtc "$run/trajectory_continuation.xtc" \
  -checkpoint "$run/continuation.chk" \
  -state_out "$run/final_state.xml" \
  -platform CPU -temp 298.15 -friction 0.01 -tstep 0.002 \
  -Nsteps 330000 -save_xtc 5000 -save_stdout 5000 \
  2>&1 | tee "$run/continuation.log"
