#!/usr/bin/env python
"""Analyze a snapshot of growing WT/AA bAIes trajectories."""

from pathlib import Path
import numpy as np
import pandas as pd
import mdtraj as md
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[2]
SNAP = Path("/tmp/baies_early_snapshot")
OUT = ROOT / "outputs/Tau5_bAIes_OpenMM/Early_Analysis"
OUT.mkdir(parents=True, exist_ok=True)
DT_NS = 0.010  # one frame per 5000 * 2 fs = 10 ps
EQUIL_NS = 0.20


def residue_number(i):
    return None if i < 2 else i + 328


all_summary = []
profiles = []
series = []
loaded = {}

for variant in ("WT", "AA"):
    traj = md.load(SNAP / f"{variant}.xtc",
                   top=ROOT / f"outputs/Tau5_bAIes_OpenMM/{variant}/protein.pdb")
    time = (np.arange(traj.n_frames) + 1) * DT_NS
    dssp = md.compute_dssp(traj, simplified=False)
    alpha = dssp == "H"
    any_helix = np.isin(dssp, ["H", "G", "I"])
    # GP occupies construct positions 1-2; ensemble summaries use AR330-447.
    alpha_fraction = alpha[:, 2:].mean(axis=1)
    any_fraction = any_helix[:, 2:].mean(axis=1)
    rg_a = md.compute_rg(traj) * 10.0
    keep = time >= EQUIL_NS
    loaded[variant] = (time, rg_a, alpha_fraction, any_fraction,
                       alpha, any_helix, keep)

    for f in range(traj.n_frames):
        series.append({"variant": variant, "frame": f+1,
                       "time_ns": time[f], "Rg_A": rg_a[f],
                       "DSSP_alpha_fraction": alpha_fraction[f],
                       "DSSP_any_helix_fraction": any_fraction[f],
                       "post_ramp": bool(keep[f])})

    for i, residue in enumerate(traj.topology.residues):
        profiles.append({
            "variant": variant,
            "construct_index": i+1,
            "residue": str(residue),
            "AR_number": residue_number(i),
            "DSSP_alpha_propensity": alpha[keep, i].mean(),
            "DSSP_any_helix_propensity": any_helix[keep, i].mean(),
        })

    def window_mean(mask, lo, hi):
        cols = [i for i in range(2, 120) if lo <= residue_number(i) <= hi]
        return mask[keep][:, cols].mean()

    all_summary.append({
        "variant": variant,
        "frames": traj.n_frames,
        "last_time_ns": time[-1],
        "post_ramp_frames": int(keep.sum()),
        "Rg_mean_A": rg_a[keep].mean(),
        "Rg_SD_A": rg_a[keep].std(ddof=1),
        "DSSP_alpha_fraction_mean": alpha_fraction[keep].mean(),
        "DSSP_alpha_fraction_SD": alpha_fraction[keep].std(ddof=1),
        "DSSP_any_helix_fraction_mean": any_fraction[keep].mean(),
        "R2_395_405_alpha_mean": window_mean(alpha, 395, 405),
        "R3_430_440_alpha_mean": window_mean(alpha, 430, 440),
    })

pd.DataFrame(series).to_csv(OUT / "early_timeseries.csv", index=False)
pd.DataFrame(profiles).to_csv(OUT / "early_per_residue_helicity.csv", index=False)
summary = pd.DataFrame(all_summary)
summary.to_csv(OUT / "early_summary.csv", index=False)

colors = {"WT": "#2f6db0", "AA": "#e56b2f"}
fig, axes = plt.subplots(3, 1, figsize=(11, 10), constrained_layout=True)
for variant, values in loaded.items():
    time, rg, alpha_frac, any_frac, alpha, any_helix, keep = values
    axes[0].plot(time, rg, color=colors[variant], lw=1.5, label=variant)
    kernel = np.ones(5)/5
    axes[1].plot(time, np.convolve(alpha_frac, kernel, mode="same"),
                 color=colors[variant], lw=1.5, label=variant)
    x = np.arange(330, 448)
    axes[2].plot(x, alpha[keep, 2:].mean(axis=0), color=colors[variant],
                 lw=2, label=variant)
for ax in axes[:2]:
    ax.axvspan(0, EQUIL_NS, color="0.85", alpha=0.8, label="temperature ramp")
    ax.set_xlim(0, max(v[0][-1] for v in loaded.values()))
axes[0].set_ylabel(r"$R_g$ (Å)")
axes[0].set_title("Early bAIes trajectories")
axes[1].set_ylabel("DSSP α-helix fraction")
axes[1].set_xlabel("Time (ns)")
axes[1].set_ylim(0, None)
axes[2].axvspan(395, 405, color="0.85", alpha=0.6, label="R2 window")
axes[2].axvspan(430, 440, color="0.92", alpha=0.6, label="R3 window")
axes[2].set_xlabel("AR residue number")
axes[2].set_ylabel("DSSP α-helix propensity")
axes[2].set_ylim(0, 1)
for ax in axes:
    ax.legend(frameon=False, ncol=3)
    ax.spines[["top", "right"]].set_visible(False)
fig.savefig(OUT / "early_Rg_and_helicity.png", dpi=200)
fig.savefig(OUT / "early_Rg_and_helicity.pdf")
print(summary.to_string(index=False))
