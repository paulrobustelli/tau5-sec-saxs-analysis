#!/usr/bin/env python
"""Prepare an AlphaFold model for the supplied coil OpenMM force field."""

from argparse import ArgumentParser
import numpy as np
from openmm import Vec3
from openmm.unit import Quantity, nanometer
from openmm.app import PDBFile, ForceField, Modeller, element


def main():
    parser = ArgumentParser()
    parser.add_argument("-pdb", required=True)
    parser.add_argument("-ff", required=True)
    parser.add_argument("-out", required=True)
    parser.add_argument("-ph", type=float, default=7.0)
    args = parser.parse_args()

    pdb = PDBFile(args.pdb)
    topology = pdb.topology
    positions = [p.value_in_unit(nanometer) for p in pdb.positions]
    residues = list(topology.residues())

    # AlphaFold models omit terminal OXT.  Add it in a planar carboxylate
    # geometry so the charged C-terminal residue template can be applied.
    terminal = residues[-1]
    atoms = {a.name: a for a in terminal.atoms()}
    if "OXT" not in atoms:
        c = np.asarray(positions[atoms["C"].index])
        o = np.asarray(positions[atoms["O"].index])
        ca = np.asarray(positions[atoms["CA"].index])
        u = (ca-c)/np.linalg.norm(ca-c)
        v = (o-c)/np.linalg.norm(o-c)
        v2 = 2*np.dot(u, v)*u-v
        v2 /= np.linalg.norm(v2)
        oxt = topology.addAtom("OXT", element.oxygen, terminal)
        topology.addBond(atoms["C"], oxt)
        positions.append(Vec3(*(c+0.125*v2)))

    modeller = Modeller(topology, Quantity(positions, nanometer))
    residues = list(modeller.topology.residues())
    templates = {
        residues[0]: "N"+residues[0].name,
        residues[-1]: "C"+residues[-1].name,
    }
    variants = ["HIE" if r.name == "HIS" else None for r in residues]
    ff = ForceField(args.ff)
    modeller.addHydrogens(ff, pH=args.ph, variants=variants,
                          residueTemplates=templates)
    # Verify the exact topology can be parameterized before writing it.
    ff.createSystem(modeller.topology, residueTemplates=templates)
    with open(args.out, "w") as handle:
        PDBFile.writeFile(modeller.topology, modeller.positions, handle,
                          keepIds=True)
    print(f"Wrote {args.out}: {len(residues)} residues, "
          f"{modeller.topology.getNumAtoms()} atoms")


if __name__ == "__main__":
    main()
