#!/usr/bin/env python3
"""Analyze the completed 10 ns bAIes runs and audit distogram preprocessing."""

from __future__ import annotations

import hashlib
import json
import pickle
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import mdtraj as md
import numpy as np
import pandas as pd
from scipy.special import softmax


HERE = Path(__file__).resolve()
REPO = HERE.parents[3]
WORKSPACE = REPO.parent.parent
SOURCE_ROOT = WORKSPACE / "outputs" / "Tau5_bAIes_OpenMM"
OUT = HERE.parents[1] / "Completed_10ns"
OUT.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(WORKSPACE / "work" / "baies_openmm"))
import preprocess_bAIes as pb  # noqa: E402

DT_NS = 0.010
EQUIL_NS = 0.20
COLORS = {"WT": "#2f6db0", "AA": "#e56b2f"}


def ar_number(construct_index: int):
    return None if construct_index < 3 else construct_index + 327


def pdb_xyz(path: Path):
    xyz = {}
    for line in path.read_text().splitlines():
        if line.startswith("ATOM"):
            xyz[int(line[6:11])] = np.array(
                [float(line[30:38]), float(line[38:46]), float(line[46:54])]
            ) * 0.1
    return xyz


def cutoff_nm(a: str, b: str):
    key = (a, b) if (a, b) in pb.cutoff_matrix else (b, a)
    return float(pb.cutoff_matrix[key][0]) * 0.1


summaries, profiles, timeseries, audit_rows, restraint_rows = [], [], [], [], []
loaded = {}

for variant in ("WT", "AA"):
    d = SOURCE_ROOT / variant
    traj = md.load(d / "trajectory.xtc", top=d / "protein.pdb")
    time = (np.arange(traj.n_frames) + 1) * DT_NS
    keep = time >= EQUIL_NS
    dssp = md.compute_dssp(traj, simplified=False)
    alpha = dssp == "H"
    any_helix = np.isin(dssp, ["H", "G", "I"])
    rg = md.compute_rg(traj) * 10.0
    alpha_fraction = alpha[:, 2:].mean(axis=1)
    any_fraction = any_helix[:, 2:].mean(axis=1)

    def window(mask, lo, hi):
        cols = [i for i in range(2, traj.n_residues) if lo <= ar_number(i + 1) <= hi]
        return mask[keep][:, cols].mean()

    summaries.append({
        "variant": variant,
        "frames": traj.n_frames,
        "time_ns": float(time[-1]),
        "analysis_start_ns": EQUIL_NS,
        "analyzed_frames": int(keep.sum()),
        "Rg_all_mean_A": float(rg.mean()),
        "Rg_all_SD_A": float(rg.std(ddof=1)),
        "Rg_post_0p2ns_mean_A": float(rg[keep].mean()),
        "Rg_post_0p2ns_SD_A": float(rg[keep].std(ddof=1)),
        "DSSP_alpha_fraction_mean": float(alpha_fraction[keep].mean()),
        "DSSP_alpha_fraction_SD": float(alpha_fraction[keep].std(ddof=1)),
        "DSSP_any_helix_fraction_mean": float(any_fraction[keep].mean()),
        "R2_395_405_alpha_mean": float(window(alpha, 395, 405)),
        "R3_430_440_alpha_mean": float(window(alpha, 430, 440)),
    })
    for f in range(traj.n_frames):
        timeseries.append({"variant": variant, "frame": f + 1,
                           "time_ns": time[f], "Rg_A": rg[f],
                           "DSSP_alpha_fraction": alpha_fraction[f],
                           "DSSP_any_helix_fraction": any_fraction[f],
                           "post_0p2ns": bool(keep[f])})
    for i, residue in enumerate(traj.topology.residues):
        profiles.append({"variant": variant, "construct_index": i + 1,
                         "AR_number": ar_number(i + 1), "residue": str(residue),
                         "DSSP_alpha_propensity": alpha[keep, i].mean(),
                         "DSSP_any_helix_propensity": any_helix[keep, i].mean()})
    loaded[variant] = (traj, time, keep, rg, alpha_fraction, alpha, any_helix)

    with open(d / "distograms.pkl", "rb") as handle:
        raw_pickle = pickle.load(handle)
    dist = raw_pickle["distogram"]
    logits = np.asarray(dist["logits"])
    edges = np.asarray(dist["bin_edges"])
    bins, probabilities = pb.read_pkl(str(d / "distograms.pkl"))
    probabilities64 = softmax(logits.astype(np.float64), axis=-1)
    pred_map = pb.read_pdb(str(d / "prediction.pdb"))
    md_map = pb.read_pdb(str(d / "protein.pdb"))
    pred_xyz = pdb_xyz(d / "prediction.pdb")

    sequence_prediction = [pred_map[i][1] for i in range(1, len(pred_map) + 1)]
    sequence_md = [md_map[i][1] for i in range(1, len(md_map) + 1)]
    serials = [int(line[6:11]) for line in (d / "protein.pdb").read_text().splitlines()
               if line.startswith("ATOM")]

    regenerated = pb.select_and_fit_distograms(
        bins, probabilities, pred_map, md_map, cutoff="matrix", seqsep=3,
        nmodes_max=1
    )
    stored = np.atleast_2d(np.loadtxt(d / "baies_params.dat", comments="#"))
    regen_table = []
    for key, value in regenerated.items():
        regen_table.append([key[2], key[3], value[2][0], np.sqrt(value[3][0])])
    regen_table = np.asarray(regen_table)

    finite_mode_pred, finite_mode_pdb = [], []
    for i in range(1, len(pred_map) + 1):
        for j in range(i + 4, len(pred_map) + 1):
            mode = pb.dmax(bins, probabilities[i - 1, j - 1])
            if mode < 2.2:
                finite_mode_pred.append(mode)
                finite_mode_pdb.append(np.linalg.norm(
                    pred_xyz[pred_map[i][0]] - pred_xyz[pred_map[j][0]]))
    finite_mode_pred = np.asarray(finite_mode_pred)
    finite_mode_pdb = np.asarray(finite_mode_pdb)

    expected_mutations = ((pred_map[70][1], pred_map[106][1]) ==
                          (("TRP", "TRP") if variant == "WT" else ("ALA", "ALA")))
    audit_rows.append({
        "variant": variant,
        "pickle_sha256": hashlib.sha256((d / "distograms.pkl").read_bytes()).hexdigest(),
        "logits_shape": "x".join(map(str, logits.shape)),
        "bin_edges": len(edges),
        "first_center_A": float(bins[0] * 10),
        "last_finite_center_A": float(bins[-1] * 10),
        "max_logit_asymmetry": float(np.max(np.abs(logits - logits.swapaxes(0, 1)))),
        "max_probability_sum_error_float16": float(np.max(np.abs(probabilities.sum(-1) - 1))),
        "max_probability_sum_error_float64": float(np.max(np.abs(probabilities64.sum(-1) - 1))),
        "pdb_residues": len(pred_map),
        "md_residues": len(md_map),
        "prediction_md_sequence_identical": sequence_prediction == sequence_md,
        "mutation_positions_correct": expected_mutations,
        "atom_serials_contiguous": serials == list(range(1, len(serials) + 1)),
        "selected_restraints": len(regenerated),
        "stored_restraints": stored.shape[0],
        "selected_atom_pairs_exact": bool(np.array_equal(regen_table[:, :2], stored[:, 1:3])),
        "max_mu_reproduction_error_nm": float(np.max(np.abs(regen_table[:, 2] - stored[:, 3]))),
        "max_sigma_reproduction_error_nm": float(np.max(np.abs(regen_table[:, 3] - stored[:, 4]))),
        "finite_mode_pairs": len(finite_mode_pred),
        "mode_vs_prediction_PDB_correlation": float(np.corrcoef(finite_mode_pred, finite_mode_pdb)[0, 1]),
        "mode_vs_prediction_PDB_RMSE_nm": float(np.sqrt(np.mean((finite_mode_pred - finite_mode_pdb) ** 2))),
    })

    atom2res = {entry[0]: idx for idx, entry in md_map.items()}
    selected_pairs = []
    for row in stored:
        ci, cj = atom2res[int(row[1])], atom2res[int(row[2])]
        selected_pairs.append((ci, cj, row))
    atom_pairs = np.asarray([[int(row[1]) - 1, int(row[2]) - 1]
                             for _, _, row in selected_pairs])
    sim_dist = md.compute_distances(traj, atom_pairs, periodic=False)
    for k, (ci, cj, row) in enumerate(selected_pairs):
        ri, rj = pred_map[ci][1], pred_map[cj][1]
        mode = pb.dmax(bins, probabilities[ci - 1, cj - 1])
        vals = sim_dist[keep, k]
        restraint_rows.append({
            "variant": variant, "construct_i": ci, "construct_j": cj,
            "AR_i": ar_number(ci), "AR_j": ar_number(cj),
            "residue_i": ri, "residue_j": rj,
            "atom_i_serial": int(row[1]), "atom_j_serial": int(row[2]),
            "sequence_separation": cj - ci,
            "distogram_mode_nm": mode,
            "selection_cutoff_nm": cutoff_nm(ri, rj),
            "gaussian_mu_nm": row[3], "gaussian_sigma_nm": row[4],
            "prediction_PDB_distance_nm": float(np.linalg.norm(
                pred_xyz[pred_map[ci][0]] - pred_xyz[pred_map[cj][0]])),
            "simulation_mean_distance_nm": float(vals.mean()),
            "simulation_SD_distance_nm": float(vals.std(ddof=1)),
            "simulation_fraction_within_mu_plusminus_sigma": float(
                np.mean(np.abs(vals - row[3]) <= row[4]))
        })

pd.DataFrame(summaries).to_csv(OUT / "summary_10ns.csv", index=False)
pd.DataFrame(timeseries).to_csv(OUT / "timeseries_10ns.csv", index=False)
pd.DataFrame(profiles).to_csv(OUT / "per_residue_helicity_10ns.csv", index=False)
pd.DataFrame(audit_rows).to_csv(OUT / "distogram_audit_summary.csv", index=False)
pd.DataFrame(restraint_rows).to_csv(OUT / "distogram_restraint_audit.csv", index=False)
(OUT / "distogram_audit.json").write_text(json.dumps(audit_rows, indent=2))

fig, axes = plt.subplots(3, 1, figsize=(11, 10), constrained_layout=True)
for variant, (traj, time, keep, rg, alpha_fraction, alpha, any_helix) in loaded.items():
    axes[0].plot(time, rg, color=COLORS[variant], lw=1, alpha=.75, label=variant)
    kernel = np.ones(20) / 20
    axes[1].plot(time, np.convolve(alpha_fraction, kernel, mode="same"),
                 color=COLORS[variant], lw=1.5, label=variant)
    axes[2].plot(np.arange(330, 448), alpha[keep, 2:].mean(axis=0),
                 color=COLORS[variant], lw=2, label=variant)
for ax in axes[:2]:
    ax.axvspan(0, EQUIL_NS, color="0.9", label="excluded first 0.2 ns")
    ax.set_xlim(0, 10)
axes[0].set(ylabel=r"$R_g$ (Å)", title="Completed 10 ns bAIes/OpenMM validation runs")
axes[1].set(ylabel="DSSP alpha-helix fraction", xlabel="Time (ns)")
axes[2].axvspan(395, 405, color="0.9", label="R2 window")
axes[2].axvspan(430, 440, color="0.95", label="R3 window")
axes[2].set(xlabel="AR residue number", ylabel="DSSP alpha-helix propensity", ylim=(0, 1))
for ax in axes:
    ax.legend(frameon=False, ncol=3)
    ax.spines[["top", "right"]].set_visible(False)
fig.savefig(OUT / "Rg_and_helicity_10ns.png", dpi=200)
fig.savefig(OUT / "Rg_and_helicity_10ns.pdf")

fig, axes = plt.subplots(1, 2, figsize=(11, 4.5), constrained_layout=True)
for variant, (_, _, keep, rg, _, _, _) in loaded.items():
    axes[0].hist(rg[keep], bins=30, density=True, histtype="step", lw=2,
                 color=COLORS[variant], label=variant)
    sub = pd.DataFrame(restraint_rows)
    sub = sub[sub.variant == variant]
    axes[1].scatter(sub.gaussian_mu_nm, sub.simulation_mean_distance_nm,
                    color=COLORS[variant], label=variant, s=35, alpha=.8)
axes[0].set(xlabel=r"$R_g$ (Å)", ylabel="Probability density", title="Post-0.2 ns size distribution")
axes[1].plot([0.5, 1.5], [0.5, 1.5], color="0.4", ls="--")
axes[1].set(xlabel="Distogram Gaussian mean (nm)", ylabel="Simulation mean distance (nm)",
            title="Selected bAIes pair distances")
for ax in axes:
    ax.legend(frameon=False)
    ax.spines[["top", "right"]].set_visible(False)
fig.savefig(OUT / "Rg_distribution_and_restraint_distances.png", dpi=200)
fig.savefig(OUT / "Rg_distribution_and_restraint_distances.pdf")

print(pd.DataFrame(summaries).to_string(index=False))
print(pd.DataFrame(audit_rows).to_string(index=False))
