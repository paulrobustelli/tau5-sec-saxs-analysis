# Tau-5* bAIes/OpenMM simulations

This directory contains the complete inputs, code, partial trajectories, and
restart states for the 120-residue GP–Tau-5* WT and W397A/W433A (`AA`)
constructs.

## Restart snapshot

`Restart_Snapshot_2026-10-09` is a consistent snapshot taken while the original
10 ns validation trajectories were running:

| construct | checkpoint step | simulated time | steps remaining to 10 ns |
|---|---:|---:|---:|
| WT | 4,670,000 | 9.34 ns | 330,000 |
| AA | 4,650,000 | 9.30 ns | 350,000 |

Each construct includes:

- `protein.pdb`: topology corresponding to the trajectory
- `trajectory_partial.xtc`: trajectory through the restart snapshot
- `restart_state.xml`: portable OpenMM state, recommended for moving machines
- `restart.chk`: exact binary checkpoint; requires compatible OpenMM platform,
  version, and hardware
- `baies_params.dat`: bAIes distance-restraint parameters
- `prediction.pdb`: source AlphaFold prediction
- `production.log` and `atom_list.ndx`

The compact restart package omits the large AlphaFold `distograms.pkl` files.
They are not required to restart because their derived restraints are already
stored in each construct's `baies_params.dat`.

## Environment

Create an environment with Python 3.11 or 3.12 and install:

```bash
python -m venv baies_env
source baies_env/bin/activate
python -m pip install "openmm==8.6.1" numpy
```

The scripts use the OpenMM CPU platform by default. After confirming a short
test on another machine, `-platform CUDA` can be used on an NVIDIA GPU or
`-platform OpenCL` where a working OpenCL backend is available.

## Continue to 10 ns

From this directory:

```bash
bash restart_WT.sh /path/to/baies_env/bin/python
bash restart_AA.sh /path/to/baies_env/bin/python
```

These commands load the portable XML states and write continuation trajectories,
checkpoints, logs, and final portable XML states without replacing the partial
trajectories. Concatenate or analyze the partial and continuation XTC files in
time order with `protein.pdb` as topology.

The 10 ns runs validate the implementation. The published bAIes IDP protocol
generated 20,000 frames at 100 ps intervals, corresponding to 2 microseconds.
